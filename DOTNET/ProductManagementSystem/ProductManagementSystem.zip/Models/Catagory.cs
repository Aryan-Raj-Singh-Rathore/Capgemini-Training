namespace ProductManagementSystem.Models
{
	public enum Category
	{
		Electronics,
		Clothing,
		Food,
		Books,
		Other
	}
}

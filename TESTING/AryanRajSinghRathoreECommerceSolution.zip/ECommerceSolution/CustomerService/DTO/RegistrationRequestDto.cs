﻿namespace CustomerService.DTO
{
    public class RegistrationRequestDto
    {
        public string? Name { get; set; }
        public string? Email { get; set; }
        public string? Phone { get; set; }
        public string? City { get; set; }
    }
}
